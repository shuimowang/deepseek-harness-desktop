/** Host configuration for the account settings client. */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './contact-config.ts';
export { Config } from './contact-config.ts';
/**
 * Publish public questionnaire options before browser plugins activate.
 * @param ctx - Host context collecting page initialization data.
 * @param config - validated deployment options.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map