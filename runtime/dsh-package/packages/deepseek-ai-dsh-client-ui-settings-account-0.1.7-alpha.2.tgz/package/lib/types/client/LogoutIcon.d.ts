/** Figma IcDsLogOutOutline16 glyph, stored inline for theme-aware rendering. */
/** @returns the account menu logout glyph. */
export declare function LogoutIcon(): import("react").JSX.Element;
//# sourceMappingURL=LogoutIcon.d.ts.map