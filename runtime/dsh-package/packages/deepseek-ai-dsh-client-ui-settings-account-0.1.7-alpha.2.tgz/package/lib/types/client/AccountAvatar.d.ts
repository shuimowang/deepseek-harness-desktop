/**
 * Render a decorative avatar next to the account identity.
 * @param props - profile picture URL; absent while signed out or loading.
 * @returns picture or the default account icon.
 */
export declare function AccountAvatar({ url }: {
    url?: string | null | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=AccountAvatar.d.ts.map