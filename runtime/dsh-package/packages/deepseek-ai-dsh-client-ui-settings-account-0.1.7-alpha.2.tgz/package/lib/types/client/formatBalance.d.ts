/**
 * Format a balance using Platform Web's two-decimal and sub-cent display rules.
 * @param amount - validated decimal balance string.
 * @param symbol - currency symbol.
 * @returns signed currency text with grouped digits.
 */
export declare function formatBalance(amount: string, symbol: '¥' | '$'): string;
//# sourceMappingURL=formatBalance.d.ts.map