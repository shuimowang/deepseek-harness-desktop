/** Curated help for shipped presets, kept separate from their short picker copy. */
export declare const guideEn: {
    modeExplanation: string;
    howToUse: string;
    guideSections: string;
    guideExampleTask: string;
    guideCopy: string;
    guideCopied: string;
    guideFootnotes: string;
    guideStandardIntro: string;
    guideStandardExplanation: string;
    guideStandardUsage: string;
    guidePtcIntro: string;
    guidePtcExplanation: string;
    guidePtcUsage: string;
    guideMinimalIntro: string;
    guideMinimalExplanation: string;
    guideMinimalUsage: string;
    guideCordisIntro: string;
    guideCordisExplanation: string;
    guideCordisUsage: string;
};
/** Keys merged into the feature’s ordinary locale seat. */
export type PresetGuideKey = keyof typeof guideEn;
/** Simplified Chinese help. Examples describe suggested tasks, not recorded runs. */
export declare const guideZh: Record<PresetGuideKey, string>;
//# sourceMappingURL=guide-locales.d.ts.map