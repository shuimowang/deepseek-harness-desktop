import type { MessageImagesProps } from '@deepseek-ai/dsh-client-ui-chat/client';
/** Historical message-image slot entry. */
export declare function MessageImages({ images, loadImage, align, compact, thumbnail, t }: MessageImagesProps): import("react").JSX.Element;
//# sourceMappingURL=MessageImages.d.ts.map