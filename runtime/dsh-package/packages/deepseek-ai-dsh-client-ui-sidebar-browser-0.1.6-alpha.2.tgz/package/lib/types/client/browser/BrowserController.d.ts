/** Per-tab Browser controller. */
import type { BoundActions } from '@deepseek-ai/dsh-client-store';
import type { TabId } from '@deepseek-ai/dsh-client-ui-dockkit';
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { BrowserFrame, BrowserFrameState } from './BrowserFrame.ts';
import type { BrowserTabState } from './BrowserNavigation.ts';
import type { BrowserStore } from './store.ts';
/** Construction dependencies for one tab-scoped Browser controller. */
export interface BrowserControllerOptions {
    readonly tabId: TabId;
    readonly signal: AbortSignal;
    readonly applicationOrigin: string;
    readonly initial?: BrowserTabState;
    readonly actions: BoundActions<BrowserStore>;
}
/** Owns one Browser tab's URL state, loading lifecycle, and four navigation commands. */
export declare class BrowserController {
    private readonly options;
    /** Renderer-facing iframe and sandbox state. */
    readonly frame: BrowserFrame;
    private readonly navigation;
    private disposed;
    /**
     * @param options - tab identity, persistence writer, URL origin, and lifetime.
     */
    constructor(options: BrowserControllerOptions);
    /**
     * Validate and load one address, replacing a same-address load with Reload.
     * @param value - address-bar or typed-tab value.
     */
    loadUrl(value: string): void;
    /** Move to the preceding application-known address when Web history remains usable. */
    goBack(): void;
    /** Move to the following application-known address when Web history remains usable. */
    goForward(): void;
    /** Reload the last application-known address without adding history. */
    reload(): void;
    private start;
    private frameLoaded;
    private publish;
    private dispose;
}
/** Browser commands and keyed frame state injected into the tab body. */
export interface BrowserInjected {
    readonly keyedHooks: {
        readonly browserFrame: (key: string) => HostObservable<BrowserFrameState> | undefined;
    };
    /**
     * @param tabId - tab occurrence.
     * @param signal - occurrence lifetime.
     * @param applicationOrigin - current application origin.
     * @param initial - persisted tab state.
     */
    mount(tabId: TabId, signal: AbortSignal, applicationOrigin: string, initial?: BrowserTabState): void;
    /** @param tabId - tab occurrence. @param value - address-bar or typed-open value. */
    loadUrl(tabId: TabId, value: string): void;
    /** @param tabId - tab occurrence. */
    goBack(tabId: TabId): void;
    /** @param tabId - tab occurrence. */
    goForward(tabId: TabId): void;
    /** @param tabId - tab occurrence. */
    reload(tabId: TabId): void;
    /** @param tabId - tab occurrence. */
    toggleSandbox(tabId: TabId): void;
    /** @param tabId - tab occurrence. @param revision - rendered document revision. */
    reportLoaded(tabId: TabId, revision: number): void;
    /** @param tabId - tab occurrence. @param revision - rendered document revision that emitted `error`. */
    reportLoadFailed(tabId: TabId, revision: number): void;
}
/**
 * Bind Browser controllers to one Session and its persistence writer.
 * @param actions - Browser store mutation face.
 * @returns a per-tab controller registry exposed as plain Slot callbacks.
 */
export declare function createBrowserControllers(actions: BoundActions<BrowserStore>): BrowserInjected;
//# sourceMappingURL=BrowserController.d.ts.map