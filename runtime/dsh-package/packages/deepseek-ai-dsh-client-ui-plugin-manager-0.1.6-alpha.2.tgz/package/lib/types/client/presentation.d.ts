/** Display labels and toast sentences for global plugin management. */
import type { ManagementError } from '@deepseek-ai/dsh-api-remotes/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ManagerNotice, PackageView } from './manager-store.ts';
/** The translate seat of the manager's dictionary. */
export type Translate = PropsLocale<'pluginManager'>['t'];
/**
 * What a management error reads as: the code's sentence, or, for an
 * operation error, the Host's diagnostic as it is.
 * @param error - the Host's code and its diagnostic, when it has one.
 * @param t - the manager's translate seat.
 * @returns the sentence.
 */
export declare function managementText(error: {
    readonly code: ManagementError['code'];
    readonly diagnostic?: string;
}, t: Translate): string;
/**
 * Compact a package name to what a person calls it.
 * @param name - the package name.
 * @returns the unscoped name without the harness prefixes.
 */
export declare function shortName(name: string): string;
/**
 * Localize known official packages by exact npm name at render time.
 * @param pkg - original package identity and optional metadata description.
 * @param t - the manager's current translate function.
 * @returns localized copy and whether the package is a beta feature, or the package's short name and original description.
 */
export declare function packageText(pkg: Pick<PackageView, 'name' | 'description'>, t: Translate): {
    title: string;
    description: string | undefined;
    beta: boolean;
};
/**
 * The sentence one notice shows.
 * @param notice - the last action's outcome.
 * @param t - the manager's translate seat.
 * @returns the sentence.
 */
export declare function noticeText(notice: ManagerNotice, t: Translate): string;
//# sourceMappingURL=presentation.d.ts.map