/**
 * One plugin's configuration form as its page on the Plugins page shows it:
 * the read-only notice when the deployment stores settings read-only, the
 * plugin's controls, and the save that writes every staged edit. The page
 * draws the plugin's title and one-liner itself.
 *
 * Only a save writes. Leaving the page drops every staged edit, so the form
 * discards on unmount and offers no discard control. A form whose namespace
 * the Host stopped serving says so in place of its controls rather than
 * showing fields nothing would accept.
 */
import { type ReactNode } from 'react';
import type { CardShell } from './card-form.ts';
import type { PluginsSettingsLocaleKey } from './locales.ts';
/** Form chrome shared by every plugin configuration page. */
export interface PluginConfigFormProps {
    /** Locale reader for this package's copy. */
    t: (key: PluginsSettingsLocaleKey) => string;
    /** The form state: availability, writability, and what a save would do. */
    state: CardShell;
    /** Write every staged edit. */
    onSave: () => void;
    /** Drop every staged edit; the form calls it when it leaves the page. */
    onDiscard: () => void;
    /** The plugin's controls. */
    children: ReactNode;
}
/**
 * Render one plugin's configuration form.
 * @param props - the form state, its controls, and the save and discard actions.
 * @returns the form, or the unavailable line while the namespace is not served.
 */
export declare function PluginConfigForm(props: PluginConfigFormProps): import("react").JSX.Element;
//# sourceMappingURL=PluginConfigForm.d.ts.map