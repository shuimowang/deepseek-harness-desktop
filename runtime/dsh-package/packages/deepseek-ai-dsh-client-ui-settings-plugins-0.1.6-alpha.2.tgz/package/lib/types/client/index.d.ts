/**
 * Built-in plugins settings surface and the official plugin configuration
 * pages, browser half. The Settings section is the shell around the
 * feature-owned tabs registered into `settings.plugins.tab` (the read-only
 * inventory ships one); the configuration pages this package ships register
 * into the Plugins page's `plugins.item` slot, for the host-plane namespaces
 * the deployment exposes, and appear in the page's Official group. Each form
 * binds its namespace through the client settings scope, which keeps the
 * pages unaware of one another and of the section.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
export type { PluginsSettingsSectionInjected, PluginsSettingsSectionProps } from './PluginsSettingsSection.tsx';
export type { PluginConfigFormProps } from './PluginConfigForm.tsx';
export type { FieldProps } from './fields.tsx';
export type { CardActions, CardFieldSpec, CardFieldState, CardSecretSpec, CardShell, } from './card-form.ts';
export type { AgentLoopCardFace, AgentLoopCardState } from './agent-loop-card-controller.ts';
export type { BashCardFace, BashCardState } from './bash-card-controller.ts';
export type { WebSearchCardFace, WebSearchCardState } from './web-search-card-controller.ts';
/** Required services (cordis fiber inject). */
export declare const inject: string[];
/**
 * Mount the built-in plugins section and the configuration pages this package ships.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map