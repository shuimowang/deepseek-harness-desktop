/** Staged delegation limits backed by the Host's subagent settings section. */
import type { SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import { type CardActions, type CardFieldState, type CardShell } from './card-form.ts';
/** Host-owned delegation defaults and live capacity. */
export interface SubagentLimitsSettings {
    maxDepth: number;
    maxActiveSubagents: number;
}
/** Effective values and drafts presented by the limits card. */
export interface SubagentLimitsCardState extends CardShell {
    maxDepth: CardFieldState;
    maxActiveSubagents: CardFieldState;
}
/** Actions and observable state bound by the slot renderer. */
export interface SubagentLimitsCardFace extends CardActions {
    hooks: {
        subagentLimitsCard: SnapshotStore<SubagentLimitsCardState>;
    };
}
/** Bind two independently resettable limits to one staged settings form. */
export declare class SubagentLimitsCardController {
    private readonly form;
    private readonly store;
    /** @param scope - The Host's `subagent` settings section. */
    constructor(scope: SettingsScope<SubagentLimitsSettings>);
    /**
     * Bind the limits editor to the slot renderer.
     * @returns The limits snapshot and staged write actions.
     */
    inject(): SubagentLimitsCardFace;
}
//# sourceMappingURL=subagent-limits-card-controller.d.ts.map