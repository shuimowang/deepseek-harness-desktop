/**
 * Process plumbing for the local subprocess service: ordinary process launch
 * with per-stream stdio dispositions, tail-keep collection with spill
 * files, provider-owned range signalling, and common termination scheduling.
 * POSIX owners stage TERM before KILL; Windows owners terminate immediately.
 * This layer reacts to an abort signal; callers own deadlines, teardown
 * ladders, and cause classification.
 * @module dsh-subprocess-local/spawn
 */
import { type ChildProcess, type SpawnOptions } from 'node:child_process';
import type { SubprocessHandle, SubprocessSpawnSpec } from '@deepseek-ai/dsh-subprocess';
import type { ManagedProcessLaunch } from './managed-owner.ts';
import { type SpillFailureReporter } from './output.ts';
type SpawnProcess = (program: string, args: readonly string[], options: SpawnOptions) => ChildProcess;
/**
 * Build a child environment: explicit caller entries override the scrubbed
 * parent base using the target platform's environment-key semantics. A string
 * deliberately restores or overrides an entry; an explicit `undefined`
 * tombstone removes an ordinary ambient entry.
 * @param extra - explicit caller entries and tombstones, merged after the scrub.
 * @returns the environment to hand to `spawn` for the child process.
 */
export declare function childEnv(extra?: Readonly<NodeJS.ProcessEnv>): NodeJS.ProcessEnv;
/** Injectable process, spill, and platform operations. */
export interface SpawnInternals {
    /** Process spawner (defaults to `node:child_process` `spawn`). */
    spawn?: SpawnProcess;
    /** Directory for spill files (defaults to the OS temp dir). */
    spillDir?: string;
    /** Receives spill open/write failures; the runtime supplies its plugin logger, bare callers get a stderr line. */
    onSpillFailure?: SpillFailureReporter;
    /** Windows tree-termination runner (defaults to `taskkill /PID <pid> /T /F`). */
    taskkill?: (pid: number) => void;
    /** Host platform override for signalling decisions. */
    platform?: NodeJS.Platform;
    /** Linux process-group member probe (defaults to `/proc` inspection). */
    linuxProcessGroupHasLiveMembers?: (processGroupId: number) => boolean | undefined;
}
/**
 * Local-only synchronous final termination used by the owning service during
 * host exit and as the last fallback after failed normal disposal. It is
 * intentionally absent from the public subprocess seam.
 */
export interface LocalSubprocessHandle extends SubprocessHandle {
    /** Force-terminate the current tree synchronously without starting timers or waits. */
    terminateForHostExit(): void;
}
/**
 * Send `sig` to a detached POSIX process group. Never throws: delivery races
 * process exit and may run in a timer callback, so failures are contained and
 * a missing pid is a no-op.
 * @param pid - the group leader's pid, when the spawn published one.
 * @param sig - the signal to deliver to the whole group.
 */
export declare function killGroup(pid: number | undefined, sig: NodeJS.Signals): void;
/**
 * Terminate one Windows process tree with `taskkill /T /F`. Contained like
 * POSIX group signalling — delivery races tree exit, so an absent tree, a
 * nonzero status, or a missing taskkill binary must not break idempotent
 * teardown.
 * @param pid - root process id, when the spawn published one.
 */
export declare function taskkillProcessTree(pid: number | undefined): void;
/**
 * Validate the synchronous portion of one ordinary spawn request.
 * @param spec - exact target request.
 * @throws when grace, cancellation, or argv is invalid before launch.
 */
export declare function validateSubprocessSpec(spec: SubprocessSpawnSpec): void;
/**
 * Bind platform launch facts to the existing stdio, outcome, abort, and termination lifecycle.
 * @param spec - fully resolved argv, cwd, stdio, grace, cancellation, environment.
 * @param launch - platform streams, direct outcome, and managed-range owner.
 * @param internals - spill-directory override and spill failure reporter.
 * @returns live subprocess handle.
 */
export declare function bindManagedProcess(spec: SubprocessSpawnSpec, launch: ManagedProcessLaunch, internals?: Pick<SpawnInternals, 'spillDir' | 'onSpillFailure'>): LocalSubprocessHandle;
/**
 * Spawn one detached PGID/taskkill fallback and bind the common lifecycle.
 * @param spec - fully resolved argv, cwd, stdio, grace, cancellation, environment.
 * @param internals - test-only spill-directory, platform, and taskkill overrides.
 * @returns live subprocess handle.
 */
export declare function spawnSubprocess(spec: SubprocessSpawnSpec, internals?: SpawnInternals): LocalSubprocessHandle;
export {};
//# sourceMappingURL=spawn.d.ts.map