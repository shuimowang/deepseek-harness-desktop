/**
 * Prepare static content before the browser can load any document resources.
 * @param data - complete UTF-8 HTML bytes.
 * @returns document with the restrictive CSP first in its head.
 */
export declare function createBasicHtmlDocument(data: Uint8Array<ArrayBuffer>): string;
//# sourceMappingURL=basic-document.d.ts.map