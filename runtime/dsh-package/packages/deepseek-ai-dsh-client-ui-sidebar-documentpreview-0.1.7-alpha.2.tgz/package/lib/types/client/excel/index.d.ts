/** Excel previews use ordinary authorized file bytes without Office conversion. */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from '../../config.ts';
/**
 * Register the browser Excel viewer and its lifecycle-owned slot.
 * @param ctx - Preview and locale registries.
 * @param limits - Resolved parser limits.
 */
export declare function apply(ctx: Context, limits: Config['excel']): void;
//# sourceMappingURL=index.d.ts.map