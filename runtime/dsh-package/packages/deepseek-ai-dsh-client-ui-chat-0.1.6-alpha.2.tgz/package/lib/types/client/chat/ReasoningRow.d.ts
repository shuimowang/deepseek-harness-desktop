import type { ChatViewSlotProps } from '../contract/slots.ts';
/**
 * Render one assistant reasoning block collapsed until the reader opens it. The
 * collapsed summary omits double-asterisk markers; expanded content renders
 * the complete Markdown with secondary typography.
 * @param props.text - complete or streaming reasoning text.
 * @param props.running - whether this block is the streaming tail.
 * @param props.t - conversation locale seat for status and Markdown actions.
 * @returns the reasoning disclosure.
 */
export declare function ReasoningRow({ text, running, t }: {
    text: string;
    running: boolean;
    t: ChatViewSlotProps['t'];
}): import("react").JSX.Element;
//# sourceMappingURL=ReasoningRow.d.ts.map