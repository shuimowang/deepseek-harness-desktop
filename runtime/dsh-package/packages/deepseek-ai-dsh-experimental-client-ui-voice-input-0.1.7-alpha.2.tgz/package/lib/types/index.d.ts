/** Host marker for the optional browser voice input contribution. */
/** Browser behavior is provided by the client export. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map