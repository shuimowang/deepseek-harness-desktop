import type { ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { WorkspaceDiffHunk } from '@deepseek-ai/dsh-workspace-changes/types';
import type { ChangesDiffStore } from './changes-diff.ts';
import type { ChangesSummaryStore } from './changes-summary.ts';
import type { PresentedOpenController } from './present-open.ts';
import type { createReviewStore } from './review-store.ts';
import type { NS } from './locales.ts';
/** Lines drawn before the tab stops; a coarse comparison of a file near the byte cap would otherwise draw every line. */
export declare const MAX_RENDERED_LINES = 5000;
/** Summary and comparison reads, desktop metadata, and the native open supplied by the plugin. */
export interface ReviewInjected {
    hooks: {
        changesSummary: ObservableSnapshot<ReturnType<ChangesSummaryStore['state']['getSnapshot']>>;
        changesDiff: ObservableSnapshot<ReturnType<ChangesDiffStore['state']['getSnapshot']>>;
        presentedOpen: ObservableSnapshot<ReturnType<PresentedOpenController['state']['getSnapshot']>>;
        presentedHost: ObservableSnapshot<ReturnType<PresentedOpenController['host']['getSnapshot']>>;
    };
    loadChangesSummary: ChangesSummaryStore['load'];
    loadChangesDiff: ChangesDiffStore['load'];
    reloadPresentedHost: PresentedOpenController['loadHost'];
    openChanged: PresentedOpenController['openChanged'];
}
/** The body's composed props: the tab it draws, its store, its injected face, and its copy. */
export type ReviewTabProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsStore<ReturnType<typeof createReviewStore>> & InjectFace<ReviewInjected> & PropsLocale<typeof NS>;
/** One drawn line of a hunk with its line numbers on each side. */
export interface DiffRow {
    kind: 'add' | 'del' | 'context';
    old: number | undefined;
    new: number | undefined;
    text: string;
}
/** One side-by-side row: the old side, the new side, or both. */
export interface SplitRow {
    left?: {
        no: number;
        text: string;
        kind: 'del' | 'context';
    };
    right?: {
        no: number;
        text: string;
        kind: 'add' | 'context';
    };
}
/**
 * Number a hunk's lines: context lines count on both sides, deletions on the
 * old side, additions on the new side.
 * @param hunk - a served hunk.
 * @returns the rows in order.
 */
export declare function hunkRows(hunk: WorkspaceDiffHunk): DiffRow[];
/**
 * Pair a hunk's lines for the side-by-side view: each run of deletions is
 * aligned with the run of additions that follows it, row by row, and context
 * lines sit on both sides.
 * @param hunk - a served hunk.
 * @returns the rows in order.
 */
export declare function splitRows(hunk: WorkspaceDiffHunk): SplitRow[];
/**
 * The hunks to draw, cut at {@link MAX_RENDERED_LINES} lines in total.
 * @param hunks - served hunks.
 * @returns the hunks with the last one shortened as needed, and whether anything was cut.
 */
export declare function renderedHunks(hunks: readonly WorkspaceDiffHunk[]): {
    hunks: WorkspaceDiffHunk[];
    truncated: boolean;
};
/**
 * The review type's body, registered under `sidebar.right.pane.tab` as `changes-review`.
 * @param props - composed slot props.
 * @returns the selected file's comparison behind the file selector, or the state that stands in for it.
 */
export declare function ReviewTab({ useTabInfo, sessionId, useSessions, useStore, actions, useChangesSummary, useChangesDiff, usePresentedOpen, usePresentedHost, loadChangesSummary, loadChangesDiff, reloadPresentedHost, openChanged, t, }: ReviewTabProps): ReactNode;
//# sourceMappingURL=ReviewTab.d.ts.map