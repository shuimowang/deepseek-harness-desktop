/** `deliverables` namespace dictionaries: cards, comparison tab, and file-mention copy. */
/** Dictionary namespace owned by this plugin. */
export declare const NS = "deliverables";
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'presented.nativeUnavailable': string;
    'presented.revealError': string;
    'presented.directoryError': string;
    'presented.directoryOpening': string;
    'presented.directoryOpened': string;
    'presented.revealed': string;
    'presented.revealing': string;
    'presented.unavailable': string;
    'presented.retry': string;
    'presented.hostError': string;
    'presented.directory': string;
    'presented.explorer': string;
    'presented.finder': string;
    'presented.defaultApp': string;
    'presented.more': string;
    'presented.action': string;
    'presented.preview': string;
    'presented.previewButton': string;
    'presented.previewCard': string;
    'presented.all': string;
    'presented.expandAria': string;
    'presented.collapse': string;
    'presented.collapseAria': string;
    'presented.opening': string;
    'presented.opened': string;
    'presented.error': string;
    'presented.file': string;
    'row.title': string;
    'row.running': string;
    'row.ok': string;
    'row.error': string;
    'row.stopped': string;
    'row.inspect': string;
    'changes.title': string;
    'changes.added': string;
    'changes.deleted': string;
    'changes.binary': string;
    'changes.openReview': string;
    'changes.all': string;
    'changes.expandAria': string;
    'changes.collapse': string;
    'changes.collapseAria': string;
    'changes.oversized': string;
    'changes.viewDiff': string;
    'review.title': string;
    'review.selectFile': string;
    'review.split': string;
    'review.unified': string;
    'review.splitAria': string;
    'review.wrap': string;
    'review.nowrap': string;
    'review.wrapAria': string;
    'review.openFile': string;
    'review.openFileAria': string;
    'diff.openNativeAria': string;
    'diff.loading': string;
    'diff.missing': string;
    'diff.error': string;
    'diff.binary': string;
    'diff.oversized': string;
    'diff.created': string;
    'diff.deleted': string;
    'diff.unchanged': string;
    'diff.coarse': string;
    'diff.truncated': string;
    'diff.openNative': string;
    'diff.openNativeError': string;
};
/** English dictionary (same key set). */
export declare const en: Record<DeliverablesKey, string>;
/** Union of this namespace's dictionary keys. */
export type DeliverablesKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map