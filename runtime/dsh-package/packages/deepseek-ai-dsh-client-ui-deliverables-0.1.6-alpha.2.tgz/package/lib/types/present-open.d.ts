/** Serve change summaries and comparisons, and open declared or changed workspace files verified by the viewed Session's filesystem. */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the deliverables routes inside Connection's authentication fence:
 * desktop metadata, change summaries and comparisons, declared-file actions,
 * and changed-file opening.
 * @param ctx - Session lookup, change summaries, native opener, and route lifetime.
 */
export declare function registerPresentOpen(ctx: Context): void;
//# sourceMappingURL=present-open.d.ts.map